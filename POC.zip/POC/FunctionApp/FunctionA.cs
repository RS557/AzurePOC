using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace FunctionApp
{
    public class FunctionA
    {
        private readonly ILogger<FunctionA> _logger;

        public FunctionA(ILogger<FunctionA> logger)
        {
            _logger = logger;
        }

        // HTTP Trigger Function
        [Function("HttpTriggerFunctionA")]
        public async Task<HttpResponseData> RunAsnc(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestData req,
            FunctionContext executionContext)
        {
            // Log the request
            _logger.LogInformation("Received a request.");

            await Task.Delay(1000);

            string name = req.Query["name"];

            if (string.IsNullOrEmpty(name))
            {
                name = "Function App";
            }

            // Create the response
            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);

            // Write message to the response
            await response.WriteStringAsync($"This is a, {name}!");

            // Log the response
            _logger.LogInformation($"Responded with: This is a, {name}!");

            return response;
        }
    }
}
