using Azure.Messaging.ServiceBus;

namespace AzureServiceBusSample
{
    public class ServiceBusSender
    {
        private const string connectionString = "service_bus_connection_string";
        private const string topicName = "MyTopic";

        public async Task SendMessageAsync(string messageContent)
        {
            var client = new ServiceBusClient(connectionString);

            var sender = client.CreateSender(topicName);

            // Create a message
            var message = new ServiceBusMessage(messageContent)
            {
                ApplicationProperties =
            {
                ["Category"] = "Sales"
            }
            };

            // Send the message
            Console.WriteLine($"Sending message: {messageContent}");
            await sender.SendMessageAsync(message);

            Console.WriteLine("Message sent.");
        }
    }
}
