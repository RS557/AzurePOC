﻿using System;
using AzureServiceBusSample;
class Program
{
    static async Task Main(string[] args)
    {
        var sender = new ServiceBusSender();
        var receiver = new ServiceBusReceiver();

        // Send a message
        await sender.SendMessageAsync("This call from Service Bus Topic Sender!");

        // Receive messages
        await receiver.ReceiveMessagesAsync("This call from Service Bus Topic Receiver!");
    }
}
