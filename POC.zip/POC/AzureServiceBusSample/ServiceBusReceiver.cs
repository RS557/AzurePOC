using Azure.Messaging.ServiceBus;

namespace AzureServiceBusSample
{
    public class ServiceBusReceiver
    {
        private const string connectionString = "service_bus_connection_string";
        private const string topicName = "MyTopic";
        private const string subscriptionName = "Subscription";
        public async Task ReceiveMessagesAsync(string messageContent)
        {
            // ServiceBusClient to interact with Service Bus
            var client = new ServiceBusClient(connectionString);

            // Receiver for the subscription
            var receiver = client.CreateReceiver(topicName, subscriptionName);

            try
            {
                // Receive a message from the subscription
                Console.WriteLine("Receiving message from subscription...");
                var message = await receiver.ReceiveMessageAsync();

                if (message != null)
                {
                    Console.WriteLine($"Received message: {message.Body}");
                    await receiver.CompleteMessageAsync(message);
                    Console.WriteLine("Message processed successfully.");
                }
                else
                {
                    Console.WriteLine("No messages available.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
            finally
            {
                await receiver.DisposeAsync();
                await client.DisposeAsync();
            }
        }
    }
}
